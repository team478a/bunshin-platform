import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { renderDialogue } from '../src/dialogue.mjs';
import { createFfmpegComposer } from '../src/ffmpeg.mjs';

const [source, destination] = process.argv.slice(2);
if (!source || !destination) throw new Error('Usage: node scripts/verify-note-baselines.mjs <built dns-intro project directory> <output-directory>');

const projectDirectory = resolve(source);
const read = async path => JSON.parse(await readFile(join(projectDirectory, path), 'utf8'));
const [story, dialogue, anchors, a, b] = await Promise.all([
  read('story.json'), read('dialogue.json'), read('audio/anchors.json'), read('output/manifest-A.json'),
  read('output/manifest-B.json'),
]);
const variants = [a, b];
const assets = new Map();
const inputs = new Map();

function captionCue(moras, token) {
  let offset = 0;
  const text = moras.map(mora => mora.text).join('');
  const start = text.indexOf(token);
  if (start < 0) throw new Error('Missing fixture caption cue: ' + token);
  for (const mora of moras) {
    if (start === offset) return mora.start;
    offset += mora.text.length;
  }
  throw new Error('Fixture cue does not start on a mora: ' + token);
}

for (const [index, manifest] of variants.entries()) {
  for (const entry of manifest.scenes) {
    const row = { ...story.scenes.find(scene => scene.id === entry.id),
      ...(index ? story.variants.B[entry.id] : {}) };
    const recipe = dialogue[entry.audioID];
    const receipt = await read('audio/' + entry.audioID + '.json');
    const spokenText = recipe.text;
    const captionPages = row.lines.map((lines, i) => ({ lines, ...(i ? { startAtMora: row.pageMoras[i - 1] } : {}) }));
    const cues = Object.fromEntries((row.pageMoras ?? []).map(token =>
      [token, { seconds: captionCue(receipt.moras, token), source: 'measured' }]));
    let diagramAction;
    if (row.action) {
      const startAtMora = recipe.anchors.action;
      const marker = anchors[entry.audioID];
      cues[startAtMora] = { seconds: marker.action, source: 'measured' };
      for (const token of row.valueAnchors ?? []) {
        if (Object.hasOwn(marker, token)) cues[token] = { seconds: marker[token], source: 'measured' };
      }
      diagramAction = { id: row.action, startAtMora, valueCueMorasInOrder: row.valueAnchors };
    }
    const voice = { engine: 'VOICEVOX Nemo', styleId: recipe.voice, speed: recipe.speed, intonation: recipe.intonation };
    const line = { id: entry.id, role: row.who, spokenText, voice, holdAfterSpeechSeconds: row.hold,
      captionPages, diagramAction, visual: { art: entry.artSha256, view: row.view } };
    const audioRef = 'audio:' + entry.audioID;
    const clipRef = 'clip:' + entry.visualSha256;
    assets.set(audioRef, join(projectDirectory, 'audio', entry.audioID + '.wav'));
    assets.set(clipRef, join(projectDirectory, 'output', entry.clip));
    inputs.set(entry.id + ':' + spokenText, { line, audio: {
      ref: audioRef, sha256: entry.voiceWavSha256, durationSeconds: entry.speechSec, cues,
    }, clip: { ref: clipRef, sha256: entry.visualSha256 }, expected: entry });
  }
}
const scope = { ownerId: 'note-baseline-fixture', projectId: 'dns-intro' };
const project = {
  id: scope.projectId, output: { width: story.width, height: story.height, fps: story.fps },
  lines: a.scenes.map(row => inputs.get(row.id + ':' + dialogue[row.audioID].text).line),
};
const adapters = {
  speechRevision: 'note-baseline-wav',
  clipRevision: 'note-baseline-clip',
  synthesize: async ({ line }) => inputs.get(line.id + ':' + line.spokenText).audio,
  renderClip: async ({ line, local }) => {
    const fixture = inputs.get(line.id + ':' + line.spokenText);
    assert.equal(local.frames, fixture.expected.frames, 'Expected the existing clip to fit exactly');
    if (local.diagram) {
      assert.ok(Math.abs(local.diagram.frame / story.fps + fixture.expected.startSec
        - fixture.expected.cue.frameSec) < .001);
    }
    return fixture.clip;
  },
  compose: createFfmpegComposer({ outputDirectory: destination, resolveAsset: (requestedScope, ref) => {
    assert.deepEqual(requestedScope, scope);
    return assets.get(ref);
  } }),
};
const original = await renderDialogue({ scope, project }, adapters);
const edit = inputs.get('04:' + dialogue['04b'].text).line;
const { id, ...changes } = edit;
const revised = await renderDialogue({ scope, project, base: original, edits: [{ lineId: id, ...changes }] }, adapters);
assert.equal(original.durationSeconds, 30.5);
assert.equal(revised.durationSeconds, 33.25);
assert.deepEqual(revised.changes.audioGenerated, ['04']);
assert.deepEqual(revised.changes.clipsGenerated, ['04']);
assert.deepEqual(revised.changes.audioReused, ['01', '02', '03', '05', '06']);
assert.deepEqual(revised.changes.clipsReused, ['01', '02', '03', '05', '06']);
for (const earlier of original.entries.filter(entry => entry.id !== '04')) {
  const later = revised.entries.find(entry => entry.id === earlier.id);
  assert.equal(later.audio.sha256, earlier.audio.sha256);
  assert.equal(later.clip.sha256, earlier.clip.sha256);
}
const reply = revised.diagramEvents.find(event => event.id === 'reply');
const secondPage = revised.captions.filter(cue => cue.lineId === '04')[1];
assert.ok(Math.abs(reply.seconds - 16.521) < .001);
assert.ok(Math.abs(reply.frame / story.fps - 16.542) < .001);
assert.ok(Math.abs(secondPage.seconds - 19.518) < .001);
assert.equal(revised.entries.find(entry => entry.id === '05').startSeconds, 22);
assert.ok(original.result.decodeVerified && revised.result.decodeVerified);
console.log(JSON.stringify({ original: original.result, revised: revised.result, changes: revised.changes,
  reply, secondPage, nextLineStartsAt: 22 }, null, 2));
