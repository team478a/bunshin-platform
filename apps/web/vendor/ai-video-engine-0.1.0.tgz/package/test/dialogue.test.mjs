import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import test from 'node:test';
import { renderDialogue } from '../src/dialogue.mjs';

const scope = { ownerId: 'local-test', projectId: 'dialogue' };
function receipt(ref) {
  return { ref, sha256: createHash('sha256').update(ref).digest('hex') };
}
function input() {
  const calls = { speech: [], clip: [], compose: 0 };
  const project = {
    id: 'dialogue', roles: { mentor: { styleId: 1 }, junior: { styleId: 2 } },
    output: { width: 720, height: 1280, fps: 24 },
    lines: [
      { id: '01', role: 'mentor', spokenText: '確認してくれる？', captionPages: [{ lines: ['確認してくれる？'] }] },
      { id: '02', role: 'junior', spokenText: '案内を検索するんですね。', diagramAction: { id: 'search', startAtMora: 'ケンサク' } },
    ],
  };
  const adapters = {
    speechRevision: 'voice-1', clipRevision: 'clip-1',
    async synthesize({ line }) {
      calls.speech.push(line.id);
      return { ...receipt(line.spokenText), durationSeconds: line.spokenText.length / 12,
        cues: { ケンサク: { seconds: .5, source: 'aligned' } } };
    },
    async renderClip({ line, local }) {
      calls.clip.push(line.id);
      return receipt(line.spokenText + ':' + local.frames);
    },
    async compose() {
      calls.compose++;
      return { mp4Ref: 'fake-result' };
    },
  };
  return { project, adapters, calls };
}

test('editing the first line moves downstream global cues while reusing the downstream WAV and clip', async () => {
  const { project, adapters, calls } = input();
  const first = await renderDialogue({ scope, project }, adapters);
  const later = await renderDialogue({ scope, project, base: first,
    edits: [{ lineId: '01', spokenText: 'この手続き、今日のうちに確認してくれる？' }] }, adapters);
  assert.deepEqual(calls.speech, ['01', '02', '01']);
  assert.deepEqual(calls.clip, ['01', '02', '01']);
  assert.equal(calls.compose, 2);
  assert.deepEqual(later.changes.clipsReused, ['02']);
  assert.deepEqual(later.entries[1].local, first.entries[1].local);
  assert.ok(later.diagramEvents[0].seconds > first.diagramEvents[0].seconds);
  assert.equal(later.diagramEvents[0].source, 'aligned');
  assert.ok(later.diagramEvents[0].frame / 24 >= later.diagramEvents[0].seconds);
});

test('opening hold starts the first caption with the voice, and the relative timing of the next clip stays fixed', async () => {
  const { project, adapters } = input();
  const first = await renderDialogue({ scope, project }, adapters);
  const later = await renderDialogue({ scope, project: { ...project, openingPauseSeconds: 1.25 }, base: first }, adapters);
  assert.equal(later.captions[0].seconds, 1.37);
  assert.equal(later.entries[1].firstFrame - first.entries[1].firstFrame, 30);
  assert.deepEqual(later.changes.audioGenerated, []);
  assert.deepEqual(later.changes.clipsGenerated, ['01']);
});

test('a missing cue uses only an authored fallback and reports its origin', async () => {
  const { project, adapters } = input();
  const edit = { lineId: '02', diagramAction: { id: 'search', startAtMora: '不明' } };
  await assert.rejects(renderDialogue({ scope, project, edits: [edit] }, adapters), /no usable speech cue/);
  edit.diagramAction.fallbackAtSpeechFraction = .4;
  const result = await renderDialogue({ scope, project, edits: [edit] }, adapters);
  assert.equal(result.diagramEvents[0].source, 'fraction');
  assert.deepEqual(result.warnings, [{ type: 'estimated-cue', label: '02 diagram search', token: '不明' }]);
});

test('a render receipt cannot be reused across project owners', async () => {
  const { project, adapters, calls } = input();
  await assert.rejects(renderDialogue({ scope, project, base: { scope: { ...scope, ownerId: 'other' } } }, adapters),
    /another scope/);
  assert.deepEqual(calls.speech, []);
});
