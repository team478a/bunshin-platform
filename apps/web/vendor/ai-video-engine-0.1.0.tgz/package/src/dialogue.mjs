import { createHash } from 'node:crypto';

function keyOf(input) {
  function ordered(value) {
    if (Array.isArray(value)) return value.map(ordered);
    if (value && typeof value === 'object') {
      return Object.fromEntries(Object.keys(value).sort().map(key => [key, ordered(value[key])]));
    }
    return value;
  }
  return createHash('sha256').update(JSON.stringify(ordered(input))).digest('hex');
}

function nonnegative(value, name) {
  if (!Number.isFinite(value) || value < 0) throw new TypeError(name + ' must be finite and nonnegative');
  return value;
}

function text(value, name) {
  if (typeof value !== 'string' || !value.trim()) throw new TypeError(name + ' is required');
}

function media(receipt, name) {
  if (!receipt || !/^[a-f0-9]{64}$/i.test(receipt.sha256 ?? '')) {
    throw new TypeError(name + ' requires a SHA-256 receipt');
  }
  text(receipt.ref, name + ' ref');
  return receipt;
}

function resolveCue(rule, audio, label, warnings) {
  const token = rule.startAtMora;
  const hit = Object.hasOwn(audio.cues ?? {}, token) ? audio.cues[token] : undefined;
  if (hit) {
    const time = nonnegative(hit.seconds, label);
    if (time >= audio.durationSeconds) throw new RangeError(label + ' is outside the WAV');
    if (!['measured', 'aligned'].includes(hit.source)) throw new TypeError(label + ' has an invalid source');
    return { token, wavSeconds: time, source: hit.source };
  }
  const fraction = rule.fallbackAtSpeechFraction;
  if (Number.isFinite(fraction) && fraction > 0 && fraction < 1) {
    warnings.push({ type: 'estimated-cue', label, token });
    return { token, wavSeconds: audio.durationSeconds * fraction, source: 'fraction' };
  }
  throw new Error(label + ' has no usable speech cue: ' + token);
}

function lineCues(line, audio, span, lead, fps, hideOpeningCaption, warnings) {
  const pages = line.captionPages ?? [];
  const starts = pages.map((page, index) => {
    if (index === 0) return { seconds: hideOpeningCaption ? lead : 0, source: 'clip' };
    const cue = resolveCue(page, audio, line.id + ' caption ' + (index + 1), warnings);
    return { ...cue, seconds: cue.wavSeconds + lead };
  });
  const captions = pages.map((page, i) => {
    const next = starts[i + 1]?.seconds ?? span / fps;
    if (next <= starts[i].seconds) throw new RangeError(line.id + ' caption cues must be in order');
    return { ...starts[i], endSeconds: next, lines: page.lines };
  });
  const action = line.diagramAction;
  if (!action) return { captions };

  const cue = resolveCue(action, audio, line.id + ' diagram ' + action.id, warnings);
  const seconds = lead + cue.wavSeconds;
  const frame = Math.ceil(seconds * fps - 1e-8);
  const duration = nonnegative(action.durationSeconds ?? .55, 'diagram duration');
  if (frame >= span) throw new RangeError(line.id + ' diagram starts beyond its clip');
  const valueToken = (action.valueCueMorasInOrder ?? [])
    .find(token => Object.hasOwn(audio.cues ?? {}, token));
  const value = valueToken
    ? resolveCue({ startAtMora: valueToken }, audio, line.id + ' diagram value', warnings) : null;
  return { captions, diagram: { ...cue, id: action.id, seconds, frame,
    completionFrame: Math.min(span - 1, frame + Math.ceil(duration * fps)),
    ...(value ? { value: { ...value, seconds: Math.max(seconds, lead + value.wavSeconds) } } : {}),
  } };
}

/**
 * Product adapters provide audio, local scene video and final composition.
 * `scope` and `base` come from the host's trusted project store.
 */
export async function renderDialogue({ scope, project, base, edits = [] }, adapters) {
  text(scope?.ownerId, 'scope.ownerId');
  text(scope?.projectId, 'scope.projectId');
  if (project?.id !== scope.projectId) throw new Error('Project does not belong to the requested scope');
  if (base && (base.scope?.ownerId !== scope.ownerId || base.scope?.projectId !== scope.projectId)) {
    throw new Error('Base render belongs to another scope');
  }
  text(adapters.speechRevision, 'speech adapter revision');
  text(adapters.clipRevision, 'clip adapter revision');
  const { fps, width, height } = project.output ?? {};
  if (![fps, width, height].every(value => Number.isInteger(value) && value > 0)) {
    throw new TypeError('output requires positive integer fps, width and height');
  }
  if (!Array.isArray(project.lines) || !project.lines.length) throw new TypeError('Project requires dialogue lines');
  const source = new Map(project.lines.map(line => [line.id, line]));
  if (source.size !== project.lines.length) throw new TypeError('Line IDs must be unique');
  const overrides = new Map();
  for (const { lineId, ...updates } of edits) {
    if (!source.has(lineId) || overrides.has(lineId) || Object.hasOwn(updates, 'id')) {
      throw new TypeError('Invalid or duplicate edit: ' + lineId);
    }
    overrides.set(lineId, updates);
  }
  const lines = [...source].map(([id, line]) => ({ ...line, ...overrides.get(id) }));
  const leadPad = nonnegative(project.leadInSeconds ?? .12, 'leadInSeconds');
  const openingFrames = Math.round(nonnegative(project.openingPauseSeconds ?? 0, 'openingPauseSeconds') * fps);
  const tail = nonnegative(project.tailOutSeconds ?? .21, 'tailOutSeconds');
  const prepared = lines.map(line => {
    text(line.id, 'line id');
    text(line.role, line.id + ' role');
    text(line.spokenText, line.id + ' spokenText');
    const voice = line.voice ?? (Object.hasOwn(project.roles ?? {}, line.role) ? project.roles[line.role] : undefined);
    if (!voice) throw new Error('Missing voice for role: ' + line.role);
    const pause = nonnegative(line.holdAfterSpeechSeconds ?? .25, line.id + ' hold');
    for (const page of line.captionPages ?? []) {
      if (!Array.isArray(page.lines) || !page.lines.length) throw new TypeError(line.id + ' caption requires lines');
      page.lines.forEach(value => text(value, line.id + ' caption text'));
    }
    if (line.diagramAction) text(line.diagramAction.id, line.id + ' action id');
    return { line, voice, pause };
  });
  const previous = new Map((base?.entries ?? []).map(entry => [entry.id, entry]));
  const records = [];
  for (const { line, voice, pause } of prepared) {
    const prior = previous.get(line.id);
    const audioKey = keyOf({ revision: adapters.speechRevision, scope, id: line.id, voice, role: line.role,
      spokenText: line.spokenText });
    const audioReused = prior?.audioKey === audioKey;
    const audio = media(audioReused ? prior.audio : await adapters.synthesize({ scope, line, voice }), line.id + ' audio');
    if (nonnegative(audio.durationSeconds, line.id + ' WAV duration') === 0) {
      throw new RangeError(line.id + ' WAV must not be empty');
    }
    records.push({ line, audio, audioKey, audioReused, prior,
      speechFrames: Math.ceil((audio.durationSeconds + pause) * fps - 1e-8) });
  }

  const firstRequired = Math.ceil((records[0].audio.durationSeconds + leadPad) * fps - 1e-8);
  const leadFrames = Math.max(Math.round(leadPad * fps), firstRequired - records[0].speechFrames);
  const baseExtraFrames = Math.ceil((leadPad + tail) * fps - 1e-8);
  if (baseExtraFrames < leadFrames) throw new RangeError('Negative tail');
  const warnings = [];
  const entries = [];
  let firstFrame = 0;
  for (const [index, record] of records.entries()) {
    const { line, audio, audioKey, audioReused, prior, speechFrames } = record;
    const lead = index === 0 ? leadPad + openingFrames / fps : 0;
    const leadExtension = index === 0 ? leadFrames + openingFrames : 0;
    const tailExtension = index === records.length - 1 ? baseExtraFrames - leadFrames : 0;
    const span = speechFrames + leadExtension + tailExtension;
    if (lead + audio.durationSeconds > span / fps + 1e-8) {
      throw new RangeError(line.id + ' speech would extend beyond its clip');
    }
    const local = { frames: span, leadSeconds: lead,
      ...lineCues(line, audio, span, lead, fps, index === 0 && openingFrames > 0, warnings) };
    const clipKey = keyOf({ revision: adapters.clipRevision, scope, id: line.id, role: line.role, audio: audio.sha256,
      output: { fps, width, height }, local, visual: line.visual ?? null, action: line.diagramAction ?? null });
    const clipReused = prior?.clipKey === clipKey;
    const clip = media(clipReused ? prior.clip : await adapters.renderClip({ scope, line, audio, local, output: project.output }),
      line.id + ' clip');
    const startSeconds = firstFrame / fps;
    entries.push({ id: line.id, role: line.role, audioKey, clipKey, audioReused, clipReused, audio, clip,
      firstFrame, lastFrame: firstFrame + span - 1, startSeconds,
      speechStartSeconds: startSeconds + lead, speechEndSeconds: startSeconds + lead + audio.durationSeconds,
      local });
    firstFrame += span;
  }
  const durationSeconds = firstFrame / fps;
  const captions = entries.flatMap(entry => entry.local.captions.map(cue => ({
    ...cue, lineId: entry.id, seconds: entry.startSeconds + cue.seconds,
    endSeconds: entry.startSeconds + cue.endSeconds,
  })));
  const diagramEvents = entries.flatMap(entry => {
    const cue = entry.local.diagram;
    return cue ? [{
      ...cue, lineId: entry.id, seconds: entry.startSeconds + cue.seconds,
      frame: entry.firstFrame + cue.frame, completionFrame: entry.firstFrame + cue.completionFrame,
      ...(cue.value ? { value: { ...cue.value, seconds: entry.startSeconds + cue.value.seconds } } : {}),
    }] : [];
  });
  const timeline = { scope: { ownerId: scope.ownerId, projectId: scope.projectId }, output: { fps, width, height },
    durationSeconds, entries, captions, diagramEvents, warnings };
  const result = await adapters.compose(timeline);
  return { ...timeline, result, changes: {
    audioGenerated: entries.filter(entry => !entry.audioReused).map(entry => entry.id),
    audioReused: entries.filter(entry => entry.audioReused).map(entry => entry.id),
    clipsGenerated: entries.filter(entry => !entry.clipReused).map(entry => entry.id),
    clipsReused: entries.filter(entry => entry.clipReused).map(entry => entry.id),
  } };
}
