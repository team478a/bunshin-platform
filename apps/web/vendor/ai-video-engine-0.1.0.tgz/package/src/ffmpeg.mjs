import { execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { promisify } from 'node:util';

const exec = promisify(execFile);
const SAMPLE_RATE = 48_000;

async function checkedPath(resolveAsset, scope, receipt) {
  const path = resolve(await resolveAsset(scope, receipt.ref));
  if (/[\r\n]/u.test(path)) throw new Error('A media path contains a line break');
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  if (hash.digest('hex') !== receipt.sha256.toLowerCase()) {
    throw new Error('Asset hash mismatch: ' + receipt.ref);
  }
  return path;
}

function concatPath(path) {
  const portable = process.platform === 'win32' ? path.replaceAll('\\', '/') : path;
  return "'" + portable.replaceAll("'", "'\\''") + "'";
}

function srtTime(seconds) {
  const ms = Math.round(seconds * 1000);
  const pad = (number, width = 2) => String(number).padStart(width, '0');
  return pad(Math.floor(ms / 3_600_000)) + ':' + pad(Math.floor(ms / 60_000) % 60)
    + ':' + pad(Math.floor(ms / 1000) % 60) + ',' + pad(ms % 1000, 3);
}

function srt(entries) {
  let count = 0;
  return entries.flatMap(entry => entry.local.captions.map(cue => [
    ++count,
    srtTime(entry.startSeconds + cue.seconds) + ' --> ' + srtTime(entry.startSeconds + cue.endSeconds),
    ...cue.lines.map(line => line.replace(/[\r\n]+/gu, ' ')),
  ].join('\n'))).join('\n\n') + '\n';
}

/**
 * A local-file adapter for FFmpeg with libass, libx264 and AAC.
 * The host resolves every reference within the supplied project scope.
 */
export function createFfmpegComposer({ outputDirectory, resolveAsset, ffmpeg = 'ffmpeg', ffprobe = 'ffprobe' }) {
  return async function compose(timeline) {
    const start = performance.now();
    const { entries, scope, durationSeconds, output } = timeline;
    await mkdir(outputDirectory, { recursive: true });
    const directory = await mkdtemp(join(resolve(outputDirectory), 'dialogue-'));
    const run = (bin, args) => exec(bin, args, { cwd: directory, windowsHide: true, timeout: 120_000 });
    const encode = (...args) => run(ffmpeg, ['-nostdin', '-v', 'error', '-y', ...args]);
    try {
      const files = await Promise.all(entries.map(async entry => ({
        voice: await checkedPath(resolveAsset, scope, entry.audio),
        clip: await checkedPath(resolveAsset, scope, entry.clip),
      })));
      const playlist = files.map(({ clip }, i) => 'file ' + concatPath(clip) + '\nduration '
        + (entries[i].local.frames / output.fps).toFixed(9)).join('\n');
      await writeFile(join(directory, 'clips.ffconcat'), 'ffconcat version 1.0\n' + playlist + '\n');
      const audioFilters = entries.map(({ local, firstFrame }, i) => {
        const sample = frame => Math.round(frame * SAMPLE_RATE / output.fps);
        const span = sample(firstFrame + local.frames) - sample(firstFrame);
        const lead = Math.round(local.leadSeconds * SAMPLE_RATE);
        return '[' + i + ':a]aresample=' + SAMPLE_RATE + ',aformat=channel_layouts=stereo,adelay=' + lead
          + 'S:all=1,apad,atrim=end_sample=' + span + ',asetpts=N/SR/TB[a' + i + ']';
      });
      audioFilters.push(entries.map((_, i) => '[a' + i + ']').join('') + 'concat=n='
        + entries.length + ':v=0:a=1[mixed]');
      await encode(...files.flatMap(({ voice }) => ['-i', voice]), '-filter_complex_threads', '1',
        '-filter_complex', audioFilters.join(';'), '-map', '[mixed]', '-c:a', 'pcm_s16le', 'preview.wav');
      const hasCaptions = entries.some(entry => entry.local.captions.length);
      if (hasCaptions) await writeFile(join(directory, 'captions.srt'), srt(entries));
      await encode('-f', 'concat', '-safe', '0', '-i', 'clips.ffconcat', '-i', 'preview.wav',
        '-map', '0:v:0', '-map', '1:a:0', ...(hasCaptions ? ['-vf', 'subtitles=captions.srt'] : []),
        '-t', String(durationSeconds), '-r', String(output.fps), '-c:v', 'libx264', '-threads', '2',
        '-preset', 'veryfast', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-ac', '2', '-b:a', '128k',
        '-metadata:s:a:0', 'language=jpn', '-disposition:a:0', 'default', '-movflags', '+faststart', 'video.mp4');
      await encode('-i', 'video.mp4', '-f', 'null', '-');
      const { stdout } = await run(ffprobe, ['-v', 'error', '-of', 'json',
        '-show_entries', 'format=duration:stream=codec_type,codec_name,width,height,channels:stream_tags=language:stream_disposition=default',
        'video.mp4']);
      const probe = JSON.parse(stdout);
      const audio = probe.streams.find(stream => stream.codec_type === 'audio');
      const video = probe.streams.find(stream => stream.codec_type === 'video');
      const actual = Number(probe.format.duration);
      if (video?.width !== output.width || video?.height !== output.height || video?.codec_name !== 'h264'
          || audio?.codec_name !== 'aac' || audio?.channels !== 2 || audio?.tags?.language !== 'jpn'
          || audio?.disposition?.default !== 1 || Math.abs(actual - durationSeconds) > 1 / output.fps) {
        throw new Error('The composed MP4 does not match the timeline or requested format');
      }
      return { mp4Ref: join(directory, 'video.mp4'), previewRef: join(directory, 'preview.wav'),
        ...(hasCaptions ? { subtitleRef: join(directory, 'captions.srt') } : {}), actualDurationSeconds: actual,
        elapsedSeconds: (performance.now() - start) / 1000, decodeVerified: true };
    } catch (error) {
      await rm(directory, { recursive: true, force: true });
      throw error;
    }
  };
}
