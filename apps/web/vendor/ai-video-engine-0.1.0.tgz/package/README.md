# ai-video-engine

会話形式の解説動画向けに、台詞の読み・声・間、字幕の切り替え、発話に合わせた図の動作、台詞単位の部分再生成を扱います。研究元は [noteのDraft PR](https://github.com/team478a/note-traffic-kit/pull/120) と [製品横断の共有Issue](https://github.com/team478a/note-traffic-kit/issues/121) です。

## 実行環境

Node.js 22以上。MP4を書き出す場合は `ffmpeg` と `ffprobe` が必要です。FFmpegは libx264・libass・AAC を有効にしたビルドを使用し、日本語フォントをOSに用意してください。検証環境は Windows、Node.js 22.15.0、FFmpeg 9.0.2 です。

```sh
npm test
node scripts/verify-note-baselines.mjs <dns-intro-project-directory> <output-directory>
```

基準動画の確認には、[noteの再生成手順](https://github.com/team478a/note-traffic-kit/pull/120/files)で用意した `tenants/studio-a/projects/dns-intro` ディレクトリを指定します。台本、WAV、モーラ時刻、A/Bのマニフェストとキャッシュ済みカットを読み、出力ディレクトリにMP4、連続試聴用WAV、字幕SRTを2セット作成します。この検証では第4台詞の差し替え素材として既存の `04b` を読み込みます。音声合成や人物・シーンの新規描画には、下記の実装を接続します。

| 検査項目 | 確認結果 |
| --- | --- |
| 完成MP4の尺 | 初版 30.500秒 / 修正版 33.250秒 |
| 変更素材 | 第4台詞のWAVとカットのみ差し替え。他の5台詞は両素材のSHA-256が一致 |
| 修正版の第4台詞 | 「返って」16.521秒、矢印の開始フレーム16.542秒（24fps）、「いわば」の字幕開始19.518秒 |
| 後続の台詞 | 第5台詞カットの開始22.000秒 |
| ファイル形式 | H.264と既定の日本語ステレオAAC。両MP4を全編デコード。720×1280、24fps |

noteの `engine/verify.py` でも書き出した2本を読み直しました。A/B各6台詞について左右両チャンネルの波形を入力WAVと照合し、録音の開始時刻は全件で予定と一致しました。図の3本の矢印は、各合図の発話からAで40.0・43.7・20.3ms後、Bで40.0・20.7・20.3ms後に画素の変化を確認しました。

## 組み込み

```js
import { renderDialogue } from 'ai-video-engine';
import { createFfmpegComposer } from 'ai-video-engine/ffmpeg';

const adapters = {
  speechRevision: 'provider-and-alignment-settings-v1',
  clipRevision: 'renderer-and-theme-v1',
  synthesize,
  renderClip,
  compose: createFfmpegComposer({ outputDirectory, resolveAsset }),
};
const initial = await renderDialogue({ scope, project }, adapters);
const revised = await renderDialogue({
  scope,
  project,
  base: initial,
  edits: [{ lineId: '04', spokenText, captionPages, diagramAction }],
}, adapters);
```

- `scope` には呼び出し元の信頼できるストアが管理する `ownerId` と `projectId` を指定します。基準レンダーもそのストアから取得します。次の修正では前回の編集を反映した最新の台本を `project` に渡します。作品の `id` は `projectId` と一致させます。
- `project` は `output: { fps, width, height }`、任意の `roles` と `openingPauseSeconds`、順序付きの `lines` を持ちます。台詞には `id`、`role`、`spokenText` を指定します。`voice` は台詞単位で指定するか `roles[role]` から取得します。`holdAfterSpeechSeconds` で次の台詞までの間を指定します。
- `captionPages` は `{ lines: string[], startAtMora? }` の配列です。2ページ目以降の合図と、`diagramAction: { id, startAtMora }` の合図をWAVから引きます。各合図は `fallbackAtSpeechFraction` を設定でき、使った場合は実行結果の `warnings` に残ります。
- `synthesize({ scope, line, voice })` は音声の `{ ref, sha256, durationSeconds, cues }` を返します。`cues` は合図のトークンをキーにした `{ seconds, source }` で、時刻はWAV先頭からの秒数、`source` は `measured` または `aligned` です。声の種類、読みや速度を変える設定は `voice` または `spokenText` に含めます。
- `renderClip({ scope, line, audio, local, output })` は `local.frames` の無音・字幕なし動画を作り、`{ ref, sha256 }` を返します。図は `local.diagram.frame` から動かします。人物原画、配役用の素材、固定レイアウトやカメラの情報は `line.visual` に含めます。メディア参照の解決は `resolveAsset(scope, ref)` が担当します。
- 合成基盤、描画アセット、合図の抽出方法など、キャッシュの結果に影響する実装を更新したときは対応するリビジョンを更新してください。台詞の長さが変わると、後続の素材を再利用しながら完成動画上の字幕・図・音声の時刻を再計算します。

音声サービスと人物・図の描画はアダプターで選べるため、AivisSpeechやVOICEVOXなどの配役設定を作品ごとに渡せます。利用者本人の原画の生成と保管、note記事・SNS向けの尺、研修の章構成は各製品が扱います。
